function validaFormulario(){

	var nome= document.frmfaleconosco.txtnome.value;
	
	var expRegNome= new RegExp("^[A-zÀ-ü]{3,}([ ]{1}[A-zÀ-ü]{2,})+$");
	
	if (!expRegNome.test(nome)){
	
		alert("Preencha o campo Nome corretamente!");
		document.frmfaleconosco.txtnome.focus();
		return false;
	}
	
	var fone=document.frmfaleconosco.txtfone.value;
	
	var expRegFone= new RegExp("[(]{1}[0-9]{2}[)]{1}[0-9]{4,5}[-]{1}[0-9]{4}$");
	
	
	if (!expRegFone.test(fone)){
		alert("Preencha o campo Telefone corretamente!");
		document.frmfaleconosco.txtfone.focus();
		return false;
	}
	
	var email=document.frmfaleconosco.txtemail.value;
	
	var expRegEmail= new RegExp ("[a-z0-9]{4,}[@]{1}[a-z]{4,}([.]{1}[a-z]{2,7})+$")
	
	if (!expRegEmail.test(email)){
		alert("Preencha o campo E-mail corretamente!");
		document.frmfaleconosco.txtemail.focus();
		return false;
	}
	
	masculino1=document.getElementById("masculino");
	feminino1=document.getElementById("feminino");
	
	if (masculino1.checked || feminino1.checked){	
	}else{	
	alert("Selecione a opção do sexo!");
	return false;
		
	}
	
		
	if (document.frmfaleconosco.data.value==""){
		alert("Preencha o campo data!");
		document.frmfaleconosco.data.focus();
		return false;
	}
		

	
	return true;
}

function validaCheckBox(){

participar2=document.getElementById("participar");
botao2=document.getElementById("botao");
botao2.disabled=false;

if (participar2.checked){
	botao2.disabled=false;
	
}else{
botao2.disabled=true;
return false;
}

return true;

}
