var valores=[]

function cadastrar(){
    
    
    var nomeCadastro = document.getElementById("txtNome")      
    var nome = String(nomeCadastro.value)
    valores.push(nome)
    var res = document.getElementById("res")

    nomeCadastro.value= ""
    nomeCadastro.focus

    console.log(valores)
    
    
    
}

function atualizar(){   

    var tabela = document.getElementById("tabela")
    var check;
    var tbody = document.createElement('tbody')       
    
        for (var c=0; c<valores.length; c++){
                check=true
                var td = document.createElement("td")  
                var tr = document.createElement("tr");          
                td.innerHTML+=`${valores[c]}`
                tr.appendChild(td)
                tbody.appendChild(tr) 
                
                            
                
        }      
                
            tabela.appendChild(tbody)
            
}

function excluir(){

    var txtNomeExcluir = document.getElementById("txtNomeExcluir")
    var nomeExcluir= String(txtNomeExcluir).value

    for(var c=0; c<valores.length; c++){

        if (valores[c]==nomeExcluir){

       valores.splice(valores).indexOf(nomeExcluir)
    
    
        }

        txtNomeExcluir= ""
        txtNomeExcluir.focus
        console.log(valores)

       
    }


        

    
