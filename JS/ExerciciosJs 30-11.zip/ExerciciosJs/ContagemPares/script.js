function contar(){
   var res=document.getElementById("res")

   var botao = document.getElementById
    for(var c=0; c<50; c++){
        if(c % 2 ==0){
            res.innerHTML+=`${c} &#128073;&#127997;` 

        }
    }
    
}