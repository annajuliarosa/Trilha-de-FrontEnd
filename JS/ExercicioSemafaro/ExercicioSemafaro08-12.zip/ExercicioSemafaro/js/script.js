imagens=[]

function acenderVermelho(){
    semafaroVermelho = document.getElementById("semafaro").src="img/semafaro-vermelho.png"
   
   
}

function acenderAmarelo(){
    semafaroAmarelo = document.getElementById("semafaro").src="img/semafaro-amarelo.png"
 
   
    
    
}

function acenderVerde(){
    semafaroVerde = document.getElementById("semafaro").src="img/semafaro-verde.png"
  

}


function acenderAutomatico(){

        for(var c=0; c<imagens.length; c++){
     
        acenderAmarelo()
        acenderVerde()
       // acenderVerde()
       // acenderVermelho()
    }
    console.log(imagens)
}


setInterval(acenderAutomatico,3000);



 
