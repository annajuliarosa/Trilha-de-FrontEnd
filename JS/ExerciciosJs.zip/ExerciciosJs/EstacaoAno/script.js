function verificar(){
    var mes = document.getElementById("txtMes")
    var estacao = Number(mes.value)
    var res= document.getElementById("res")

    if(estacao=>3 || estacao<6){
        res.innerHTML="A estação é: Outono"

    }else if (estacao=>6 && estacao<9){
        res.innerHTML="A estação é: Inverno"

    }else if (estacao>9 && estacao<12){
        res.innerHTML="A estação é: Primavera"
    }else{
        res.innerHTML="A estação é: Verão"
    }
}