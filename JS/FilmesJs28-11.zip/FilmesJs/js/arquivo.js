var valores=[]

function cadastrar(){
    
    var nomeCadastro = document.getElementById("txtNome")      
    var nome = String(nomeCadastro.value)

        valores.push(nome)
            var res = document.getElementById("res")

                nomeCadastro.value= ""
                nomeCadastro.focus
                console.log(valores)
    
}

function atualizar(){   

    var tabela = document.getElementById("tabela")
    var tbody = document.createElement('tbody')       

    tabela.innerHTML="<b>Nome<b>"
    
        for (var c=0; c<valores.length; c++){               
                var td = document.createElement("td")
                var tr = document.createElement("tr") 
                tr.setAttribute('onclick', "excluir('"+valores[c]+"')")
                td.innerHTML+=`${valores[c]}`
                tr.appendChild(td)
                tbody.appendChild(tr) 

        }                   
                tabela.appendChild(tbody)   
}

function excluir(nomeExcluir){

    console.log(nomeExcluir)
    
    if(nomeExcluir==""){

        var txtNomeExcluir = document.getElementById("txtNomeExcluir")
        nomeExcluir= String((txtNomeExcluir).value)
        txtNomeExcluir.value= ""
        txtNomeExcluir.focus    
      
    }else{

        var check=false
   

        for(var c=0; c<valores.length; c++){ 
            if (valores[c]==nomeExcluir){
                    valores.splice(c,1)   
                    check=true;
                    alert("Item excluido da tabela!")
            }
        }

        if(check==false){
            alert("Esse item não existe na tabela ou está vazio!") 
        }
      
       
    } 
        

    }

    
        

        
    


    
