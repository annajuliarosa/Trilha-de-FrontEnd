function calcular(){
    var nome = document.getElementById("txtNome")
    var altura = document.getElementById("txtAltura")
    var peso = document.getElementById("txtPeso")

    var res = document.getElementById("res")

    var valorNome = String(nome.value)
    var valorAltura = parseFloat(altura.value)
    var valorPeso = parseFloat(peso.value)

    if(valorAltura<1){       
        alert("Altura digitada é invalida!!")  
        document.getElementById("txtAltura").focus()
    }else if(valorPeso<1){
        alert("Peso digitado é invalido!!")
        document.getElementById("txtPeso").focus()
    }else{  

    var calculo = parseFloat(valorPeso / valorAltura **2).toFixed(2)
   
    if (calculo <18.5){
        var classificacao="Magreza"
    }else if (calculo>=18.5 && calculo<24.9){
        var classificacao="Normal"
    }else if(calculo >=25 && calculo<29.9){
        var classificacao="Sobrepeso"
    }else if(calculo>=30 && calculo<39.9){
        var classificacao="Obesidade grau ||"
    }else {
        var classificacao="Obesidade grave grau |||	"
    }
    
    res.innerHTML = `${valorNome} seu IMC é de ${calculo} e a sua situação é de ${classificacao}`
}

}