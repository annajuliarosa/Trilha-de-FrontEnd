function acenderVermelho(semafaro){
    semafaro = document.getElementById("semafaro").src="img/semafaro-vermelho.png"    
}

function acenderAmarelo(semafaro){
    semafaro = document.getElementById("semafaro").src="img/semafaro-amarelo.png"  
}

function acenderVerde(semafaro){
    semafaro = document.getElementById("semafaro").src="img/semafaro-verde.png"  
}

