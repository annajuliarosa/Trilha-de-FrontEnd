function calcular(){
    var nome = document.getElementById("txtNome")
    var altura = document.getElementById("txtAltura")
    var peso = document.getElementById("txtPeso")

    var res = document.getElementById("res")

    var valorNome = String(nome.value)
    var valorAltura = parseFloat(altura.value)
    var valorPeso = parseFloat(peso.value)

    var expRegNome = new RegExp("^[A-z]{3,}([ ]{1}[A-zÀ-ü]{2,})+$")
    var expRegAltura = new RegExp("^[1-2]{1}[.]{1}[1-9]{2}$")
    var expRegPeso = new RegExp("^[0-9]{2,3}$")

    if(!expRegNome.test(valorNome)){
        alert("Preencha o campo nome corretamente!")
        document.getElementById("txtNome").focus()  

    }else if(valorAltura<1 || !expRegAltura.test(valorAltura)){       
        alert("Altura digitada é invalida!!")  
        document.getElementById("txtAltura").focus()

    }else if(valorPeso<1 || !expRegPeso.test(valorPeso)){
        alert("Peso digitado é invalido!!")
        document.getElementById("txtPeso").focus()  

    }else{  

    var calculo = parseFloat(valorPeso / valorAltura **2).toFixed(2)
   
    if (calculo <18.5){
        var classificacao="Magreza"
    }else if (calculo>=18.5 && calculo<24.9){
        var classificacao="Normal"
    }else if(calculo >=25 && calculo<29.9){
        var classificacao="Sobrepeso"
    }else if(calculo>=30 && calculo<39.9){
        var classificacao="Obesidade grau ||"
    }else {
        var classificacao="Obesidade grave grau |||	"
    }
    
    res.innerHTML = `${valorNome} seu IMC é de ${calculo} e a sua situação é ${classificacao}`
}

}