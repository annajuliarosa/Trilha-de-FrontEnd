var valores=[]

function cadastrar(){
    
    var nomeCadastro = document.getElementById("txtNome")      
    var nome = String(nomeCadastro.value)

        valores.push(nome)
            var res = document.getElementById("res")

                nomeCadastro.value= ""
                nomeCadastro.focus
                console.log(valores)
    
}

function atualizar(){   

    var tabela = document.getElementById("tabela")
    var tbody = document.createElement('tbody')       

    tabela.innerHTML="<b>Nome<b>"
    
        for (var c=0; c<valores.length; c++){               
                var td = document.createElement("td")
                var tr = document.createElement("tr")      
                    td.innerHTML+=`${valores[c]}`
                    tr.appendChild(td)
                    tbody.appendChild(tr) 
        }                   
            tabela.appendChild(tbody)

            tr.onclick= function(){
                
                    for(var c=0; c<valores.length; c++){
                        excluir(td)            
                    } 

            }           
}

function excluir(nomeExcluir){

    var txtNomeExcluir = document.getElementById("txtNomeExcluir")
    nomeExcluir= String((txtNomeExcluir).value)

    if(valores.length!=0){
        for(var c=0; c<valores.length; c++){        
                if (valores[c]==nomeExcluir){
                    valores.splice(c,1)            
                }
        }
            alert("Excluido")
    }else{
            alert("Não há filmes ou séries para excluir!")
        }

        txtNomeExcluir.value= ""
        txtNomeExcluir.focus
        console.log(valores)
    
} 

    
